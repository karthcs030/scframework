package org.totalqa.tests;
 
import org.testng.Assert;
import org.testng.IHookable;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.totalqa.pages.LoginPage;
import org.totalqa.util.BaseClass;
import org.totalqa.util.DataFetcher;
import java.io.IOException;
import org.testng.Reporter;
 
public class LoginTests extends BaseClass implements IHookable

{
	@DataProvider(name = "WIT_INFO", parallel = true)
	public Object[][] OrderAccountPagination() {
		String testDataPath = "C:\\NotBackedUp\\SCF_services_Automation\\com.anz.scf.services.automation\\src\\binaries\\wit_details.xlsx";
		String sheetName = "Sheet4";
		return new DataFetcher(testDataPath).getDataFromXlsxtbySheetName(sheetName);
	}
		
	@Test(description="Validate Login Functionality with invalid credentials",priority=0, enabled=true)
	public static void login_invalid() throws InterruptedException, IOException 
	{
		LoginPage login = new LoginPage(driver);
		
		String actual =   login.invalidlogin("perftest051@globaltest.anz.com", "Welcome5"); 
		String expected= "Bank Guarantee Summary";
		screenCapture();
		
		if ((actual.equals("Supply Chain Financing Summary")))
		{
		Reporter.log("Login Sucessful!!!! Congragulations" + "</br>");
		}
		
		else {
		Reporter.log("Login Failed!!! Something Went wrong" + "</br>");
		}
		
		
		Assert.assertEquals(actual,expected);
		
		
	}
	
	
	@Test(description="Validate Login Functionality",priority=1, enabled=true)
	public static void login() throws InterruptedException, IOException  
	{
		LoginPage login = new LoginPage(driver);
		
		String actual =   login.login("perftest059@globaltest.anz.com", "Welcome1"); 
		String expected= "Supply Chain Financing Summary";
		
		
		if ((actual.equals("Supply Chain Financing Summary")))
		{
		Reporter.log("Login Sucessful!!!! Congragulations"+ "</br>");
		}
		
		else {
		Reporter.log("Login Failed!!! Something Went wrong"+ "</br>");
		}
		
		Assert.assertEquals(actual,expected);
		screenCapture();
	}
	
	@Test(description="Validate Audit link Functionality",priority=2,enabled=false)
	public static void clickonaudit() throws InterruptedException, IOException  
	{
		LoginPage login = new LoginPage(driver);
		
		String actual = LoginPage.clickonauditlink();
		String expected= "Bank Guarantee Summary";
		
		screenCapture();
		Assert.assertEquals(actual,expected);
		
	}

	@Test(description="Validate Input/Output Functionality",priority=3, enabled=false)
	public static void clickonIOQueue() throws InterruptedException, IOException  
	{
		LoginPage login = new LoginPage(driver);
		
		String actual = LoginPage.clickonIOLInk();
		String expected= "Input/Output Queue";
		screenCapture();
		Assert.assertEquals(actual,expected);
		
	}
	
	@Test(description="Validate Make button funtionality",priority=4,enabled=true)
	public static void clickOnMake() throws InterruptedException, IOException 
	{
		LoginPage login = new LoginPage(driver);
		
		String actual = LoginPage.clickonOnMake();
		
		Reporter.log("Sucessfully clicked on the all the Make buttons");
		screenCapture();
	}
	
	@Test(description="Validate pagination function",priority=5,enabled=true)
	public static void clickOnpagination() throws InterruptedException, IOException 
	{
		LoginPage login = new LoginPage(driver);
		
		String actual = LoginPage.clickonOnpagination();
		Reporter.log("SUCESS: Pagination links are working fine.");
		screenCapture();
	}
	
	@Test(description="Validate Sort functionality of WIT",priority=6,enabled=true)
	public static void clickOnsortWIT() throws InterruptedException, IOException
	{
		LoginPage login = new LoginPage(driver);
		boolean expected = true;
		boolean actual = LoginPage.clickOnsortWIT();
		Reporter.log("SUCESS: Sort function of WIT Type."+"</br>");
		screenCapture();
		//Assert.assertEquals(actual,expected);
		
	}
	
	@Test(description="Validate Sort functionality of OPERORG",priority=7,enabled=true)
	public static void clickOnsortOperorg() throws InterruptedException, IOException
	{
		LoginPage login = new LoginPage(driver);
		boolean expected = true;
		boolean actual = LoginPage.clickOnsortOperorg();
		Reporter.log("SUCESS: Sort function of OPER ORG."+"</br>");
		screenCapture();
		//Assert.assertEquals(actual,expected);
		
	}
	
	@Test(description="Validate Sort functionality of Amount",priority=8,enabled=true)
	public static void clickOnsortAmount() throws InterruptedException, IOException
	{
		LoginPage login = new LoginPage(driver);
		boolean expected = true;
		boolean actual = LoginPage.clickOnsortAmount();
		Reporter.log("SUCESS: Sort function of OPER ORG."+"</br>");
		screenCapture();
		//Assert.assertEquals(actual,expected);
		
	}
	
	@Test(description="Validate Sort functionality of OPERORG",priority=9,enabled=true)
	public static void clickOnOPERORG() throws InterruptedException, IOException
	{
		LoginPage login = new LoginPage(driver);
		boolean expected = true;
		boolean actual = LoginPage.clickOnsortAmount();
		Reporter.log("SUCESS: Sort function of OPER ORG."+"</br>");
		screenCapture();
		//Assert.assertEquals(actual,expected);
		
	}
	
	@Test(description="Validate Sort functionality of Hub Due date",priority=10,enabled=true)
	public static void clickOnsorthubduedate() throws InterruptedException, IOException
	{
		LoginPage login = new LoginPage(driver);
		boolean expected = true;
		boolean actual = LoginPage.clickonsorthubduedate();
		Reporter.log("SUCESS: Sort function of OPER ORG."+"</br>");
		screenCapture();
		//Assert.assertEquals(actual,expected);
		
	}
	
	@Test(description="Validate Sort functionality of OPERORG",priority=11,enabled=true)
	public static void clickOnsortlogtime() throws InterruptedException, IOException
	{
		LoginPage login = new LoginPage(driver);
		boolean expected = true;
		boolean actual = LoginPage.clickonsortlogtime();
		Reporter.log("SUCESS: Sort function of OPER ORG."+"</br>");
		screenCapture();
		//Assert.assertEquals(actual,expected);
		
	}
	
	
	
	@Test(dataProvider="WIT_INFO", description="Validate pagination function",priority=12,enabled=true)
	public static void clickOnrefresh(String WIT_ID, String WIT_Type, String OPER_ORG, String Funding_Amount, String Party, String Prioirty, String Status) throws InterruptedException, IOException 
	{
		LoginPage login = new LoginPage(driver);
		
		String actual = LoginPage.clickonOnrefresh(WIT_Type);
		String expected = "";
		//Assert.assertEquals(actual,expected);
		Reporter.log("SUCESS: Refresh functionality is working fine."+"</br>");
		screenCapture();
	}

	@Test(dataProvider="WIT_INFO", enabled=true, priority=13, description="Validate filter: WIT Type")
	public static void clickonWitItems(String WIT_ID, String WIT_Type, String OPER_ORG, String Funding_Amount, String Party, String Prioirty, String Status) throws InterruptedException, IOException 
	{
		LoginPage login = new LoginPage(driver);
		String actual = LoginPage.enterwittype(WIT_Type);
		Thread.sleep(2000);
		String expected = "Fin Receivables";
		//int WIT_ID_Converted = Integer.parseInt(WIT_ID);
		
		//String actual = LoginPage.clickonOnpagination();
		Reporter.log(WIT_ID + WIT_Type);
		screenCapture();
		Assert.assertEquals(actual,expected);
		
	}
	
	@Test(dataProvider="WIT_INFO", enabled=true, priority=15, description="Invalid Validate filter: WIT Type")
	public static void clickonWitItemswithinvaliddata(String WIT_ID, String WIT_Type, String OPER_ORG, String Funding_Amount, String Party, String Prioirty, String Status) throws InterruptedException, IOException 
	{
		LoginPage login = new LoginPage(driver);
		String actual = LoginPage.enterwittype(WIT_Type);
		Thread.sleep(2000);
		String expected = "";
		//int WIT_ID_Converted = Integer.parseInt(WIT_ID);
		
		//String actual = LoginPage.clickonOnpagination();
		Reporter.log(WIT_ID + WIT_Type);
		screenCapture();
		Assert.assertEquals(actual,expected);
		
	}
	
	@Test(dataProvider="WIT_INFO", enabled=true, priority=16, description="Validate filter: Funding amount")
	public static void clickonfundingamount(String WIT_ID, String WIT_Type, String OPER_ORG, String Funding_Amount, String Party, String Prioirty, String Status) throws InterruptedException, IOException 
	{
		LoginPage login = new LoginPage(driver);
		String actual = LoginPage.clickonfundingamount(Funding_Amount);
		Thread.sleep(2000);
		String expected = "94";
		//int WIT_ID_Converted = Integer.parseInt(WIT_ID);
		
		//String actual = LoginPage.clickonOnpagination();
		//Reporter.log(WIT_ID + WIT_Type);
		screenCapture();
		Assert.assertEquals(actual,expected);
		
	}

	@Test(dataProvider="WIT_INFO", enabled=true, priority=14, description="Validate filter: Customer")
	public static void clickoncustomer(String WIT_ID, String WIT_Type, String OPER_ORG, String Funding_Amount, String Party, String Prioirty, String Status) throws InterruptedException, IOException 
	{
		LoginPage login = new LoginPage(driver);
		String actual = LoginPage.clickoncustomer(Party);
		Thread.sleep(2000);
		String expected = "94";
		//int WIT_ID_Converted = Integer.parseInt(WIT_ID);
		
		//String actual = LoginPage.clickonOnpagination();
		//Reporter.log(WIT_ID + WIT_Type);
		screenCapture();
		//Assert.assertEquals(actual,expected);
		
	}
	
	@Test(dataProvider="WIT_INFO", enabled=true, priority=17, description="Validate filter: Customer")
	public static void clickonWIT(String WIT_ID, String WIT_Type, String OPER_ORG, String Funding_Amount, String Party, String Prioirty, String Status) throws InterruptedException, IOException 
	{
		LoginPage login = new LoginPage(driver);
		String actual = LoginPage.clickonWIT(WIT_ID);
		Thread.sleep(2000);
		String expected = "94";
		//int WIT_ID_Converted = Integer.parseInt(WIT_ID);
		
		//String actual = LoginPage.clickonOnpagination();
		//Reporter.log(WIT_ID + WIT_Type);
		screenCapture();
		//Assert.assertEquals(actual,expected);
		
	}


	@Test(description="Validate Logout Functionality",priority=18,enabled=true)
	public static void clickOnLogout() throws InterruptedException, IOException 
	{
		LoginPage login = new LoginPage(driver);
		
		String actual = LoginPage.clickonOnLogout();
		String expected= "Log out successfully.";
		Assert.assertEquals(actual,expected);
		Reporter.log(expected);
		screenCapture();
	}
	
	@Test(description="Validate Close Window",priority=20,enabled=true)
	public static void Closebrowserwindow() throws InterruptedException, IOException 
	{
		LoginPage login = new LoginPage(driver);
		login.quitdriver(driver);
		
		
	}

 
}
package org.totalqa.tests;
 
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.IHookable;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.totalqa.pages.LoginPage;
import org.totalqa.pages.MakerReview;
import org.totalqa.util.BaseClass;
import org.totalqa.util.DataFetcher;
import java.io.IOException;
import java.util.List;

import org.testng.Reporter;
 
public class MakerReviewTests extends BaseClass implements IHookable

{
	@DataProvider(name = "WIT_INFO", parallel = false)
	public Object[][] OrderAccountPagination() {
		String testDataPath = "C:\\NotBackedUp\\project_code\\HybridFramework-master\\HybridFramework-master\\Hybridframework\\Hybridframework\\Design\\Wit_info.xlsx";
		String sheetName = "Sheet1";
		return new DataFetcher(testDataPath).getDataFromXlsxtbySheetName(sheetName);
	}
	
	@Test(description="Validate Login Functionality",priority=1, enabled=true)
	public static void login() throws InterruptedException, IOException  
	{
		LoginPage login = new LoginPage(driver);
		
		String actual =   login.login("perftest059@globaltest.anz.com", "Welcome1"); 
		String expected= "Supply Chain Financing Summary";
		
		
		if ((actual.equals("Supply Chain Financing Summary")))
		{
		Reporter.log("Login Sucessful!!!! Congragulations"+ "</br>");
		}
		
		else {
		Reporter.log("Login Failed!!! Something Went wrong"+ "</br>");
		}
		screenCapture();
		Assert.assertEquals(actual,expected);
		
	}
	
	@Test(enabled=true, priority=2)
	public static void SearchWITbynumber() throws InterruptedException, IOException 
	{
		Thread.sleep(5000);
		LoginPage login = new LoginPage(driver);
		//MakerReview.serachwitinsummary(driver);
		
		//for (int i=0;i<2;i++)
		//{
		Thread.sleep(2000);
		//for (int i = 0; i<WIT_ID.length();i++)
		//{
		driver.findElement(By.xpath("//*[@id=\'root\']/div/div[1]/div/div/div[2]/div/div/div[1]/div[1]/table/thead/tr/th[1]/div/input")).sendKeys("22339622");
		Thread.sleep(3000);
		
		
		//}
	}
		
	

	
	
	@Test(description="Validate Make button funtionality",priority=3,enabled=true)
	public static void clickOnMake() throws InterruptedException, IOException 
	{
		LoginPage login = new LoginPage(driver);
		
		String actual = LoginPage.clickonOnMake();
		
		Reporter.log("Sucessfully clicked on the all the Make buttons");
		screenCapture();
	}
	
	
	@Test(description="Validate Zoom in Functionality",priority=4,enabled=true)
	public static void clickOnZoomin() throws InterruptedException, IOException 
	{
		
		
		LoginPage login = new LoginPage(driver);
		
		String actual = MakerReview.clickonOnZoomin(driver);
		
		
		screenCapture();
	}
	
	@Test(description="Validate Zoom out Functionality",priority=5,enabled=true)
	public static void clickOnZoomout() throws InterruptedException, IOException 
	{
		
		
		LoginPage login = new LoginPage(driver);
		
		MakerReview.clickonOnZoomout(driver);
		
		
		screenCapture();
	}
	
	@Test(description="Validate Entity List Tab",priority=6,enabled=true)
	public static void clickOnEntity() throws InterruptedException, IOException 
	{
		
		
		LoginPage login = new LoginPage(driver);
		
		MakerReview.clickOnEntity(driver);
		
		
		screenCapture();
	}
	
	@Test(description="Validate Highlight Functionality",priority=7,enabled=true)
	public static void clickOnHighlight() throws InterruptedException, IOException 
	{
		
		
		LoginPage login = new LoginPage(driver);
		
		MakerReview.clickOnHighlight(driver);
		
		
		screenCapture();
	}
	
	@Test(description="Validate Rotate Functionality",priority=7,enabled=true)
	public static void clickOnRotate() throws InterruptedException, IOException 
	{
		
		
		LoginPage login = new LoginPage(driver);
		
		MakerReview.clickonrotate(driver);
		
		
		screenCapture();
	}
	
	@Test(description="Validate WIT Details on top of the page",priority=8,enabled=true)
	public static void getWITDetails() throws InterruptedException, IOException 
	{
		
		
		LoginPage login = new LoginPage(driver);
		
		List<WebElement> actual = MakerReview.getWITdetails(driver);
		
		
		screenCapture();
		Assert.assertNull(actual);
	}
	
	@Test(description="Validate next page link in document",priority=8,enabled=false)
	public static void clickonnextpage() throws InterruptedException, IOException 
	{
		
		
		LoginPage login = new LoginPage(driver);
		
		String actual = MakerReview.clickonnextpage(driver);
		
		
		screenCapture();
		//Assert.assertNotNull(actual);
	}
	
	@Test(description="Validate previous page link in document",priority=9,enabled=false)
	public static void clickonpreviouspage() throws InterruptedException, IOException 
	{
		
		
		LoginPage login = new LoginPage(driver);
		
		String actual = MakerReview.clickonpreviouspage(driver);
		
		
		screenCapture();
		//Assert.assertNotNull(actual);
	}
	
	
	@Test(description="Validate Discepancies button Functionality",priority=9,enabled=false)
	public static void clickondiscrepancies() throws InterruptedException, IOException 
	{
		
		
		LoginPage login = new LoginPage(driver);
		
		String actual = MakerReview.clickondiscrepancies(driver);
		
		
		screenCapture();
		Assert.assertNull(actual);
	}
	
	@Test(description="Validate Close functionality of Discrepancies tab",priority=10,enabled=false)
	public static void clickonclosediscrepancies() throws InterruptedException, IOException 
	{
		
		
		LoginPage login = new LoginPage(driver);
		
		String actual = MakerReview.clickonclosediscrepancies(driver);
		
		
		screenCapture();
		Assert.assertNull(actual);
	}
	
	@Test(description="Validate CLAA Functionality",priority=11,enabled=true)
	public static void clickOnCLAA() throws InterruptedException, IOException 
	{
		
		
		LoginPage login = new LoginPage(driver);
		
		String actual = MakerReview.clickOnDST(driver);
		Reporter.log("Text Found in the DST stub:" +actual);
		
		
		screenCapture();
		Assert.assertNull(actual);
	}
	
	@Test(description="Validate Zoom in Functionality",priority=12,enabled=true)
	public static void clickOnclaaZoomin() throws InterruptedException, IOException 
	{
		
		
		LoginPage login = new LoginPage(driver);
		
		String actual = MakerReview.clickonOnCLAAZoomin(driver);
		
		
		screenCapture();
	}
	
	@Test(description="Validate Zoom out Functionality of CLAA Document",priority=13,enabled=true)
	public static void clickOnclaaZoomout() throws InterruptedException, IOException 
	{
		
		
		LoginPage login = new LoginPage(driver);
		
		String actual = MakerReview.clickonOnCLAAZoomin(driver);
		
		
		screenCapture();
	}
	
	@Test(description="Validate Rotate Functionality of CLAA Document",priority=14,enabled=true)
	public static void clickOnClaaRotate() throws InterruptedException, IOException 
	{
		
		
		LoginPage login = new LoginPage(driver);
		
		MakerReview.clickonclaarotate(driver);
		
		
		screenCapture();
	}
	
	
	@Test(description="Validate Approveall Functionality",priority=15,enabled=true)
	public static void clickOnApproveAll() throws InterruptedException, IOException 
	{
		
		
		LoginPage login = new LoginPage(driver);
		
		boolean actual = MakerReview.clickOnApproveAll(driver);
		Reporter.log("Text box is disabled:" +actual);
		
		
		screenCapture();
		Assert.assertFalse(actual);
	}
	
	@Test(description="Validate UndoAll Functionality",priority=16,enabled=true)
	public static void clickOnUndoAll() throws InterruptedException, IOException 
	{
		
		
		LoginPage login = new LoginPage(driver);
		
		boolean actual = MakerReview.clickOnUndoAll(driver);
		Reporter.log("Text box is disabled:" +actual);
		
		
		screenCapture();
		Assert.assertTrue(actual);
	}
	
	@Test(description="Validate text box functionality",priority=17,enabled=true)
	public static void clickOnTextBox() throws InterruptedException, IOException 
	{
		
		
		LoginPage login = new LoginPage(driver);
		
		String actual = MakerReview.sendtextboxtotext(driver);
		
		//String expected = "https://mlaas-bgtee-ui-mlaas-bgtee.apps.cpaas.qa.service.test/ui/summary";
		//Reporter.log("Text box is disabled:" +actual);
		
		
		screenCapture();
		//Assert.assertEquals(actual, expected);
	}
	
	@Test(description="Validate Approve button functionality",priority=18,enabled=true)
	public static void clickOnApprove() throws InterruptedException, IOException 
	{
		
		
		LoginPage login = new LoginPage(driver);
		
		String actual = MakerReview.clickonapprove(driver);
		
		//String expected = "https://mlaas-bgtee-ui-mlaas-bgtee.apps.cpaas.qa.service.test/ui/summary";
		//Reporter.log("Text box is disabled:" +actual);
		
		
		screenCapture();
		//Assert.assertEquals(actual, expected);
	}
	
	@Test(description="Validate Undo button functionality",priority=19,enabled=true)
	public static void clickOnUndo() throws InterruptedException, IOException 
	{
		
		
		LoginPage login = new LoginPage(driver);
		
		String actual = MakerReview.clickonundo(driver);
		
		//String expected = "https://mlaas-bgtee-ui-mlaas-bgtee.apps.cpaas.qa.service.test/ui/summary";
		//Reporter.log("Text box is disabled:" +actual);
		
		
		screenCapture();
		//Assert.assertEquals(actual, expected);
	}
	
	@Test(description="Validate PrimaryInfo Details functionality",priority=20,enabled=true)
	public static void Clickonprimaryinteractions() throws InterruptedException, IOException 
	{
		
		
		LoginPage login = new LoginPage(driver);
		
		String actual = MakerReview.clickonprimary(driver);
		
		//String expected = "https://mlaas-bgtee-ui-mlaas-bgtee.apps.cpaas.qa.service.test/ui/summary";
		//Reporter.log("Text box is disabled:" +actual);
		
		
		screenCapture();
		//Assert.assertEquals(actual, expected);
	}
	
	
	@Test(description="Validate Party Tab Details functionality",priority=21,enabled=true)
	public static void clickpartytabinteractions() throws InterruptedException, IOException 
	{
		
		
		LoginPage login = new LoginPage(driver);
		
		String actual = MakerReview.clickpartytabinteractions(driver);
		
		//String expected = "https://mlaas-bgtee-ui-mlaas-bgtee.apps.cpaas.qa.service.test/ui/summary";
		//Reporter.log("Text box is disabled:" +actual);
		
		
		screenCapture();
		//Assert.assertEquals(actual, expected);
	}
	
	@Test(description="Validate tenor details tab",priority=22,enabled=true)
	public static void clickontenordetails() throws InterruptedException, IOException 
	{
		
		
		LoginPage login = new LoginPage(driver);
		
		String actual = MakerReview.clickontenordetails(driver);
		
		//String expected = "https://mlaas-bgtee-ui-mlaas-bgtee.apps.cpaas.qa.service.test/ui/summary";
		//Reporter.log("Text box is disabled:" +actual);
		
		
		screenCapture();
		//Assert.assertEquals(actual, expected);
	}
	
	
	@Test(description="Validate Charges Tab",priority=23,enabled=true)
	public static void clickOnCharges() throws InterruptedException, IOException 
	{
		
		
		LoginPage login = new LoginPage(driver);
		
		String actual = MakerReview.clickOnCharges(driver);
		
		//String expected = "https://mlaas-bgtee-ui-mlaas-bgtee.apps.cpaas.qa.service.test/ui/summary";
		//Reporter.log("Text box is disabled:" +actual);
		
		
		screenCapture();
		//Assert.assertEquals(actual, expected);
	}
	
	@Test(description="Validate Charges tab interactions",priority=24,enabled=true)
	public static void clickonChargesInteractions() throws InterruptedException, IOException 
	{
		
		
		LoginPage login = new LoginPage(driver);
		
		String actual = MakerReview.clickonchargesinteractions(driver);
		
		//String expected = "https://mlaas-bgtee-ui-mlaas-bgtee.apps.cpaas.qa.service.test/ui/summary";
		//Reporter.log("Text box is disabled:" +actual);
		
		
		screenCapture();
		//Assert.assertEquals(actual, expected);
	}
	
	@Test(description="Validate PDF tab fucntionality",priority=21,enabled=false)
	public static void selectPDFtab() throws InterruptedException, IOException 
	{
		
		
		LoginPage login = new LoginPage(driver);
		
		String actual = MakerReview.selectpdftab(driver);
		
		//String expected = "https://mlaas-bgtee-ui-mlaas-bgtee.apps.cpaas.qa.service.test/ui/summary";
		//Reporter.log("Text box is disabled:" +actual);
		
		
		screenCapture();
		//Assert.assertEquals(actual, expected);
	}
	

	@Test(description="Selecting Document Type: Application Form",priority=22,enabled=false)
	public static void selectdocumenttype() throws InterruptedException, IOException 
	{
		
		
		LoginPage login = new LoginPage(driver);
		
		String actual = MakerReview.selectdocumentbytype(driver);
		
		//String expected = "https://mlaas-bgtee-ui-mlaas-bgtee.apps.cpaas.qa.service.test/ui/summary";
		//Reporter.log("Text box is disabled:" +actual);
		
		
		screenCapture();
		//Assert.assertEquals(actual, expected);
	}
	
	@Test(description="Selecting Document Type: Invoice",priority=25,enabled=true)
	public static void selectinvoicetab() throws InterruptedException, IOException 
	{
		
		
		LoginPage login = new LoginPage(driver);
		
		String actual = MakerReview.selectdocumentinvoice(driver);
		
		//String expected = "https://mlaas-bgtee-ui-mlaas-bgtee.apps.cpaas.qa.service.test/ui/summary";
		//Reporter.log("Text box is disabled:" +actual);
		
		
		screenCapture();
		//Assert.assertEquals(actual, expected);
	}
	
	@Test(description="Selecting Document Type: Razor",priority=26,enabled=true)
	public static void selectRazorlimits() throws InterruptedException, IOException 
	{
            LoginPage login = new LoginPage(driver);
            
		
		String actual = MakerReview.clickonRazor(driver);
		screenCapture();
	}
	
	@Test(description="Validate functioanlity of Submit WIT",priority=28,enabled=true)
	public static void clickonsubmitwit() throws InterruptedException, IOException 
	{
		
		
		LoginPage login = new LoginPage(driver);
		
		String actual = MakerReview.clickonsubmitwit(driver);
		
		//String expected = "https://mlaas-bgtee-ui-mlaas-bgtee.apps.cpaas.qa.service.test/ui/summary";
		//Reporter.log("Text box is disabled:" +actual);
		
		
		screenCapture();
		//Assert.assertEquals(actual, expected);
	}
	
	@Test(description="Validate functioanlity of Close Submit WIT",priority=29,enabled=true)
	public static void clickonclosesubmitwit() throws InterruptedException, IOException 
	{
		
		
		LoginPage login = new LoginPage(driver);
		
		String actual = MakerReview.clickonclosesubmitwit(driver);
		
		//String expected = "https://mlaas-bgtee-ui-mlaas-bgtee.apps.cpaas.qa.service.test/ui/summary";
		//Reporter.log("Text box is disabled:" +actual);
		
		
		screenCapture();
		//Assert.assertEquals(actual, expected);
	}
	
	@Test(description="Validate functioanlity of HOLD WIT",priority=27,enabled=true)
	public static void clickonholdwit() throws InterruptedException, IOException 
	{
		
		
		LoginPage login = new LoginPage(driver);
		
		String actual = MakerReview.clickonholdwit(driver);
		
		
		//String expected = "https://mlaas-bgtee-ui-mlaas-bgtee.apps.cpaas.qa.service.test/ui/summary";
		//Reporter.log("Text box is disabled:" +actual);
		
		
		screenCapture();
		//Assert.assertEquals(actual, expected);
	}
	
	@Test(description="Validate Back to Summary",priority=30,enabled=true)
	public static void clickOnBacktoSumamry() throws InterruptedException, IOException 
	{
		Thread.sleep(5000);
		
		LoginPage login = new LoginPage(driver);
		
		String actual = MakerReview.clickonbacktosummary(driver);
		
		String expected = "https://mlaas-scf-ui-mlaas-qa-scf.apps.cpaas.service.test/ui/summary";
		//Reporter.log("Text box is disabled:" +actual);
		
		
		screenCapture();
		Assert.assertEquals(actual, expected);
	}
	
	@Test(description="Validate Logout Functionality",priority=40,enabled=false)
	public static void clickOnLogout() throws InterruptedException, IOException 
	{
		Thread.sleep(5000);
		LoginPage login = new LoginPage(driver);
		
		String actual = LoginPage.clickonOnLogout();
		String expected= "Log out successfully.";
		Assert.assertEquals(actual,expected);
		Reporter.log(expected);
		screenCapture();
	}

	@Test(description="Validate close window functionality",priority=50,enabled=false)
	public static void closebrowserwindow() throws InterruptedException, IOException 
	{
		LoginPage login = new LoginPage(driver);
		
		login.quitdriver(driver);
	}
	
}
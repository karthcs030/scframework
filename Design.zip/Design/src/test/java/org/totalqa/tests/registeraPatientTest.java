package org.totalqa.tests;
 
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.IHookable;
import org.testng.annotations.Test;
import org.totalqa.pages.LoginPage;
import org.totalqa.pages.navigatetosummary;

import org.totalqa.util.BaseClass;
 
public class registeraPatientTest extends BaseClass implements IHookable
{
	@Test(description="Validate register a Patient Functionality",priority=1)
	public static void loginregister() throws InterruptedException 
	{
		
		LoginPage login = new LoginPage(driver);
		login.login("meena88_iamtestpass", "Intuit@123");
		navigatetosummary reggi = new navigatetosummary(driver);
		String actual = reggi.register();
		String expected = "0081032529";
				
		Assert.assertEquals(actual,expected);
	}
 
}
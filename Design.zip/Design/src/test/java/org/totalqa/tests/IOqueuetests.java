package org.totalqa.tests;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.IHookable;
import org.testng.Reporter;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.totalqa.pages.IOQueue;
import org.totalqa.pages.LoginPage;
import org.totalqa.pages.navigatetosummary;
import org.totalqa.util.BaseClass;
import org.totalqa.util.DataFetcher;
 
public class IOqueuetests extends BaseClass implements IHookable

{
	//Data provider to read the test data from excel and apply on the methods where it is called
	@DataProvider(name = "WIT_INFO", parallel = false)
	public Object[][] OrderAccountPagination() {
		String testDataPath = "C:\\NotBackedUp\\project_code\\HybridFramework-master\\HybridFramework-master\\Hybridframework\\Hybridframework\\Design\\Wit_info.xlsx";
		String sheetName = "Sheet2";
		return new DataFetcher(testDataPath).getDataFromXlsxtbySheetName(sheetName);
	}
	
	@Test(description="Verify Input WIT tab",priority=1, enabled=true)
	public static void navigatetoIO() throws InterruptedException 
	{
		
		LoginPage login = new LoginPage(driver);
		login.login("perftest019@globaltest.anz.com", "Welcome1"); 
		LoginPage.clickonIOLInk();
		IOQueue.ClickonInputWIT(driver);
		//String actual = return_date.substring(0,9);
		//String expected = datereturn();
		
		
		//Assert.assertEquals(actual,expected);
	}
	
	@Test(description="Verify Infoview tab",priority=3, enabled=true)
	public static void infoviewtab() throws InterruptedException 
	{
		//LoginPage login = new LoginPage(driver);
	//IOQueue datepicker = IOQueue.dateenter(driver);
		LoginPage login = new LoginPage(driver);
		//login.login("perftest019@globaltest.anz.com", "Welcome1"); 
		//LoginPage.clickonIOLInk();
		String actual= IOQueue.infoviewTabTesting(driver);
		String expected = "13-May-2019";
		
		
		//Assert.assertEquals(actual,expected);
	}
	
	@Test(description="Verify Reconillation report tab",priority=4, enabled=true)
	public static void reconcillation_report_tab() throws InterruptedException 
	{
		//LoginPage login = new LoginPage(driver);
	//IOQueue datepicker = IOQueue.dateenter(driver);
		LoginPage login = new LoginPage(driver);
		//login.login("perftest019@globaltest.anz.com", "Welcome1"); 
		//LoginPage.clickonIOLInk();
		String actual= IOQueue.reconcillationTesting(driver);
		String expected = "13-May-2019";
		
		
		//Assert.assertEquals(actual,expected);
	}


	@Test(description="Change the From date and TO Date",priority=2, enabled=true)
	public static void clickonIORefresh() throws InterruptedException 
	{
		//LoginPage login = new LoginPage(driver);
	//IOQueue datepicker = IOQueue.dateenter(driver);
		LoginPage login = new LoginPage(driver);
		//login.login("perftest019@globaltest.anz.com", "Welcome1"); 
		//LoginPage.clickonIOLInk();
		String actual= IOQueue.clickiorefresh(driver);
		String expected = "13-May-2019";
		
		
		//Assert.assertEquals(actual,expected);
	}
	
	@Test(description="Validate the Sumamry link Functionality",priority=5, enabled=true)
	public static void clickonSummary() throws InterruptedException 
	{
		
		LoginPage login = new LoginPage(driver);
		//login.login("perftest019@globaltest.anz.com", "Welcome1"); 
		//LoginPage.clickonIOLInk();
		String actual= IOQueue.clickonsummary(driver);
		String expected = "Supply Chain Financing Summary";
		
		
		Assert.assertEquals(actual,expected);
	}
	

	@Test(description="Validate Logout Functionality",priority=6,enabled=false)
	public static void clickOnLogout() throws InterruptedException, IOException 
	{
		LoginPage login = new LoginPage(driver);
		
		String actual = LoginPage.clickonOnLogout();
		String expected= "Log out successfully.";
		Assert.assertEquals(actual,expected);
		Reporter.log(expected);
		screenCapture();
	}

	@Test(description="Validate Close window Functionality",priority=10,enabled=true)
	public static void closebrowserwindow() throws InterruptedException, IOException 
	{
		LoginPage login = new LoginPage(driver);
		
		login.quitdriver(driver);
	}
	
}

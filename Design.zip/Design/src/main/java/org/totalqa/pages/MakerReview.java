package org.totalqa.pages;


import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.totalqa.util.*;
 
public class MakerReview{
 
	static WebDriver driver;
	static ConfigFileReader configFileReader;
	static configDataFetcher configdata;
	
	 
 
	public MakerReview(WebDriver driver)
	{
		this.driver = driver;
		configFileReader= new ConfigFileReader();
 
	}



	public static String clickonOnZoomin(WebDriver driver) throws InterruptedException {
		
		Thread.sleep(3000);
		Reporter.log("Clicking on the Zoom In button"+"</br>");
		
		for (int i =0;i<10;i++)
		{
			driver.findElement(By.xpath(configDataFetcher.configData("Zoom_in"))).click();
		}
		
		Reporter.log("Clicked on the Zoom in buttons 10 times");
		return null;
	}
	
public static String clickonOnZoomout(WebDriver driver) throws InterruptedException {
	
	Thread.sleep(3000);
	Reporter.log("Clicking on the Zoom out button"+"</br>");
		for (int i =0;i<10;i++)
		{
			driver.findElement(By.xpath(configDataFetcher.configData("Zoom_out"))).click();
		}
		
		Reporter.log("Clicked on the Zoom out buttons 10 times");
		return null;
	}

public static String clickonOnCLAAZoomin(WebDriver driver) throws InterruptedException {
	
	Thread.sleep(3000);
	Reporter.log("Clicking on the Zoom In button"+"</br>");
	
	for (int i =0;i<10;i++)
	{
		driver.findElement(By.xpath(configDataFetcher.configData("claa_zoom_in"))).click();
	}
	
	Reporter.log("Clicked on the Zoom in buttons 10 times");
	return null;
}

public static String clickonOnCLAAZoomout(WebDriver driver) throws InterruptedException {

Thread.sleep(3000);
Reporter.log("Clicking on the Zoom out button"+"</br>");
	for (int i =0;i<10;i++)
	{
		driver.findElement(By.xpath(configDataFetcher.configData("claa_zoom_out"))).click();
	}
	
	Reporter.log("Clicked on the Zoom out buttons 10 times");
	return null;
}


public static void clickOnEntity(WebDriver driver) throws InterruptedException {
	
	/*Reporter.log("Clicking on the Entity List tab"+"</br>");
	driver.findElement(By.id(configDataFetcher.configData("entity_list"))).click();
	Reporter.log("Clicking on the Primary Info"+"</br>");
	driver.findElement(By.xpath(configDataFetcher.configData("primary_info"))).click();*/
	
	Reporter.log("Clicking on the Party Tab"+"</br>");
	driver.findElement(By.xpath(configDataFetcher.configData("party_tab"))).click();
	
	
}



public static void clickOnHighlight(WebDriver driver) {
	
	Reporter.log("Clicking on the Primary Info"+"</br>");
	driver.findElement(By.xpath(configDataFetcher.configData("primary_info"))).click();
	//driver.findElement(By.xpath(configDataFetcher.configData("primary_info"))).click();
	Reporter.log("Checking for highlight button"+"</br>");
	//driver.findElements(By.tagName(configDataFetcher.configData("highlight")));
	
	List<WebElement> highlight_button = driver.findElements(By.xpath(configDataFetcher.configData("highlight")));
	int n = highlight_button.size();
	for (int i = 0;i<n; i++)
	{
		highlight_button.get(i).click();
		Reporter.log("Clicking on highlight button"+"</br>");
	}
	
}



public static void clickonrotate(WebDriver driver) throws InterruptedException {
	
	Reporter.log("Clicking on the Rotate Button"+"</br>");
	
	Thread.sleep(3000);
	
	for (int i=0;i<4;i++)
	{
		driver.findElement(By.xpath(configDataFetcher.configData("rotate_document"))).click();
	}
	Reporter.log("Sucess: Clicked on Rotate button 4 times"+"</br>");
}



public static List<WebElement> getWITdetails(WebDriver driver) {
	Reporter.log("Trying to Read WIT Details on the Top Banner"+"</br>");
	List<WebElement> banner_details = driver.findElements(By.xpath(configDataFetcher.configData("wit_banner")));
	for (int i=0;i<banner_details.size();i++)
	{
		String details = banner_details.get(i).getText();
		Reporter.log(details);
	}
	;
	return null;
	
}



public static String clickondiscrepancies(WebDriver driver) {
	
	Reporter.log("Clicking on Discrepancies tab"+"</br>");
	driver.findElement(By.xpath(configDataFetcher.configData("discrepancies"))).click();
	Reporter.log("Sucess!! Discrepancies tab is clicked and screenshot captured"+"</br>");
	return null;
}



public static String clickonclosediscrepancies(WebDriver driver) {
	
	Reporter.log("Clicking on close button of Discrepancies tab"+"</br>");
	driver.findElement(By.xpath(configDataFetcher.configData("close_discrepancy"))).click();
	Reporter.log("Sucess!! Discrepancies tab Close button is clicked"+"</br>");
	return null;
	
}



public static String clickOnDST(WebDriver driver) {
	Reporter.log("Clicking on CLAA Tab"+"</br>");
	driver.findElement(By.xpath(configDataFetcher.configData("DST"))).click();
	Reporter.log("Sucessfully clicked on the CLAA tab. Caaturing screenshot"+"</br>");
	//driver.findElement(By.xpath(configDataFetcher.configData("DST_text"))).click();
	//String s = driver.findElement(By.xpath(configDataFetcher.configData("DST_text"))).getText();
	return null;
}



public static boolean clickOnApproveAll(WebDriver driver) throws InterruptedException {
	
	
	
	Reporter.log("Clicking on Approve All button"+"</br>");
	driver.findElement(By.xpath(configDataFetcher.configData("approve_all"))).click();
	
	Thread.sleep(7000);
	Reporter.log("Clicking on the Primary Info"+"</br>");
	driver.findElement(By.xpath(configDataFetcher.configData("primary_info"))).click();
	boolean disabled_text = driver.findElement(By.tagName("input")).isEnabled();

	
	return disabled_text;
}



public static boolean clickOnUndoAll(WebDriver driver) throws InterruptedException {
	
	Reporter.log("Clicking on Undo All button"+"</br>");
	driver.findElement(By.xpath(configDataFetcher.configData("undo_all"))).click();
	Thread.sleep(7000);
	
	//Reporter.log("Clicking on the Primary Info"+"</br>");
	//driver.findElement(By.xpath(configDataFetcher.configData("primary_info"))).click();
	boolean disabled_text = driver.findElement(By.tagName("input")).isEnabled();

	
	return disabled_text;
	
}



public static String clickonbacktosummary(WebDriver driver) throws InterruptedException {
	Reporter.log("Clicking on Back to Summary Button"+"</br>");
	JavascriptExecutor js = (JavascriptExecutor) driver;
	js.executeScript("window.scrollBy(1000,0)");
	driver.findElement(By.xpath(configDataFetcher.configData("backto_summary"))).click();
	Thread.sleep(3000);
	String s = driver.getCurrentUrl();
	return s;
}



public static String sendtextboxtotext(WebDriver driver) throws InterruptedException {
	
	Reporter.log("Looking for text fields in Maker Review Screen"+"</br>");
	//driver.findElement(By.cssSelector(configDataFetcher.configData("undo_all"))).click();
	//WebDriverWait wait = new WebDriverWait(driver, 40);
	//wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.tagName("//input[@type='text']"))));
	//Thread.sleep(3000);
	 List<WebElement> txtfields = driver.findElements(By.className("form-control"));
	  
	  //for loop to send text In all text box one by one.
	  for(int a=0; a<txtfields.size();a++){   
	   txtfields.get(a).sendKeys("Text"+(a+1));  
	  }
	  Reporter.log("Sent test data for all the text fields"+"</br>");
	return null;
}



public static String clickonapprove(WebDriver driver) {

	Reporter.log("Looking for Approve Button"+"</br>");
	//driver.findElement(By.cssSelector(configDataFetcher.configData("undo_all"))).click();
	//WebDriverWait wait = new WebDriverWait(driver, 40);
	//wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.tagName("//input[@type='text']"))));
	//Thread.sleep(3000);
	 List<WebElement> txtfields = driver.findElements(By.linkText("Approve"));
	  
	  //for loop to send text In all text box one by one.
	  for(int a=0; a<txtfields.size();a++){   
	   txtfields.get(a).click();  
	  }
	  Reporter.log("Clicked on all the Aprprove buttons"+"</br>");
	return null;
	
	
}



public static String clickonundo(WebDriver driver) {
	
	Reporter.log("Looking for Undo Button"+"</br>");
	//driver.findElement(By.cssSelector(configDataFetcher.configData("undo_all"))).click();
	//WebDriverWait wait = new WebDriverWait(driver, 40);
	//wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.tagName("//input[@type='text']"))));
	//Thread.sleep(3000);
	 List<WebElement> txtfields = driver.findElements(By.linkText("Undo"));
	  
	  //for loop to send text In all text box one by one.
	  for(int a=0; a<txtfields.size();a++){   
	   txtfields.get(a).click();  
	  }
	  Reporter.log("Clicked on all the Undo buttons"+"</br>");
	return null;
}



public static String clickOnCharges(WebDriver driver) {
	Reporter.log("Clicking on Charges tab"+"</br>");
	driver.findElement(By.xpath(configDataFetcher.configData("charges"))).click();
	Reporter.log("Sucess!!! Clicked on Charges Tab"+"</br>");
	return null;
}



public static String clickonchargesinteractions(WebDriver driver) throws InterruptedException {
	
	/*Reporter.log("Clicking on Approve All button"+"</br>");
	driver.findElement(By.cssSelector(configDataFetcher.configData("approve_all"))).click();
	
	Reporter.log("Clicking on Undo All button"+"</br>");
	driver.findElement(By.cssSelector(configDataFetcher.configData("undo_all"))).click();*/
	
	sendtextboxtotext(driver);
	clickonapprove(driver);
	clickonundo(driver);
	
	return null;
}



public static String clickpartytabinteractions(WebDriver driver) throws InterruptedException {
	Reporter.log("Clicking on the Party Tab"+"</br>");
	driver.findElement(By.xpath(configDataFetcher.configData("party_tab"))).click();
	//sendtextboxtotext(driver);
	clickonapprove(driver);
	clickonundo(driver);
	
	return null;
}



public static String selectdocumentbytype(WebDriver driver) {
	/*Reporter.log("Clicking on the PDF tab"+"</br>");
	driver.findElement(By.id(configDataFetcher.configData("pdf_tab"))).click();
	Reporter.log("Clicked on the PDF tab"+"</br>");*/
	
	Reporter.log("Clicking on Document Type: Applicationform"+"</br>");
	 driver.findElement(By.xpath(configDataFetcher.configData("arrow_mark"))).click();

	
	return null;
}



public static String selectpdftab(WebDriver driver) throws InterruptedException {
	
	Reporter.log("Clicking on the PDF tab"+"</br>");
	driver.findElement(By.id(configDataFetcher.configData("pdf_tab"))).click();
	Reporter.log("Clicked on the PDF tab"+"</br>");
	Reporter.log("Clicking on the Application form"+"</br>");
	Actions action = new Actions(driver);
	driver.findElement(By.className("PDFComponent__rightTop")).click();
	action.sendKeys(Keys.ARROW_DOWN);
	action.sendKeys(Keys.ARROW_DOWN);
	action.sendKeys(Keys.ENTER);
	action.build().perform();
	
	Thread.sleep(3000);
	Reporter.log("Sucess!!! Clicked on the Application form"+"</br>");
	return null;
}



public static String selectdocumentclaa(WebDriver driver) throws InterruptedException {
	
	Reporter.log("Clicking on the PDF tab"+"</br>");
	Actions action = new Actions(driver);
	Reporter.log("Clicking on CLAA Document"+"</br>");
			driver.findElement(By.className("PDFComponent__rightTop")).click();
			action.sendKeys(Keys.ARROW_DOWN);
			action.sendKeys(Keys.ARROW_DOWN);
			action.sendKeys(Keys.ENTER);
			action.build().perform();
			Thread.sleep(3000);
			Reporter.log("Sucess!!! Clicked on the CLAA document"+"</br>");
			
	
	/*for (int i = 0;i<ele.size();i++)
	{
		Reporter.log(ele.get(i).getText());
		ele.get(i).sendKeys(Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ENTER);
		if ((ele.get(i).getText()).equals("CLAA"))
		{
			ele.get(i).click();
			Thread.sleep(3000);
			ele.get(i).sendKeys(Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ENTER);
		}
	}
	
	/*Java script approach
	WebElement dropdown = driver.findElement(By.xpath(configDataFetcher.configData("arrow_mark")));
	JavascriptExecutor js = (JavascriptExecutor)driver;	
	 js.executeScript("arguments[0].value='CLAA';", dropdown);
	 dropdown.click();
	 dropdown.sendKeys("CLAA");
	 dropdown.sendKeys(Keys.RETURN);
	 //js.executeScript("var evt = document.createEvent('HTMLEvents');evt.initEvent('change', true, true);arguments[0].dispatchEvent(evt);", dropdown);
	//driver.findElement(By.cssSelector(configDataFetcher.configData("application_form"))).sendKeys("APPLICATION_FORM");
	//Keys.ENTER;
	driver.findElement(By.xpath(configDataFetcher.configData("arrow_mark"))).sendKeys(Keys.DOWN, Keys.DOWN, Keys.ENTER);
	
	//driver.findElement(By.xpath(configDataFetcher.configData("arrow_mark"))).sendKeys(Keys.DOWN);
	//driver.findElement(By.xpath(configDataFetcher.configData("arrow_mark"))).sendKeys(Keys.ENTER);
	Thread.sleep(5000);*/
	
	return null;
	
	
}



public static String clickonsubmitwit(WebDriver driver) throws InterruptedException {

	Reporter.log("Clicking on Submit WIT button"+"</br>");
	driver.findElement(By.xpath(configDataFetcher.configData("submit_wit"))).click();
	Thread.sleep(15000);
	Reporter.log("Sucess submit WIT button clicked Sucefully!!"+"</br>");
	Reporter.log("Clicking on Approve all pop up"+"</br>");
	driver.findElement(By.xpath(configDataFetcher.configData("Approved_entities"))).click();
	Reporter.log("Sucess submit WIT button clicked Sucefully!!"+"</br>");
	Thread.sleep(3000);
	
	
	return null;
}



public static String clickonclosesubmitwit(WebDriver driver) {

	Reporter.log("Clicking on Cancel Submit WIT button"+"</br>");
	Reporter.log("Scrolling down in the page");
	JavascriptExecutor js = (JavascriptExecutor) driver;
	js.executeScript("window.scrollBy(0,1000)");
	//driver.switchTo().alert().dismiss();
	driver.findElement(By.xpath(configDataFetcher.configData("close_submitwit"))).click();
	//Thread.sleep(3000);
	Reporter.log("Sucess Cancel WIT button clicked Sucefully!!"+"</br>");
	
	return null;
}



public static String clickonnextpage(WebDriver driver) {
	Reporter.log("Clicking on Next page link in Document preview"+"</br>");
	for(int i=0;i<3;i++)
	{
	driver.findElement(By.xpath(configDataFetcher.configData("next_page"))).click();
	}
	return null;
}



public static String clickonpreviouspage(WebDriver driver) {
	Reporter.log("Clicking on previous page link in Document preview"+"</br>");
	for(int i=0;i<3;i++)
	{
	driver.findElement(By.xpath(configDataFetcher.configData("previous_page"))).click();
	}
	return null;
}



public static String selectdocumentinvoice(WebDriver driver) {

	Reporter.log("Clicking on Invoice tab"+"</br>");
	driver.findElement(By.xpath(configDataFetcher.configData("invoice"))).click();
	return null;
}



public static String clickonRazor(WebDriver driver) throws InterruptedException {

	Reporter.log("Clicking on Razor Limits tab"+"</br>");
	Thread.sleep(2000);
	driver.findElement(By.xpath(configDataFetcher.configData("razor"))).click();
	Reporter.log("Sucess: Captured RAZOR Screenshot"+"</br>");
	Thread.sleep(2000);
	
	return null;
}



public static String clickonholdwit(WebDriver driver) throws InterruptedException {
	Reporter.log("Clicking on Hold Wit button"+"</br>");
	JavascriptExecutor js = (JavascriptExecutor) driver;
	js.executeScript("window.scrollBy(1000,0)");
	Thread.sleep(3000);
	driver.findElement(By.xpath(configDataFetcher.configData("hold_wit"))).click();
	
	Thread.sleep(2000);
	driver.findElement(By.xpath(configDataFetcher.configData("hold_no"))).click();
	
	return null;
}



public static String clickonprimary(WebDriver driver) throws InterruptedException {
	Reporter.log("Clicking on Primary info button"+"</br>");
	Thread.sleep(3000);
	driver.findElement(By.xpath(configDataFetcher.configData("primary_info"))).click();
	return null;
}



public static String clickontenordetails(WebDriver driver) throws InterruptedException {
	
	Reporter.log("Clicking on Primary info button"+"</br>");
	Thread.sleep(3000);
	driver.findElement(By.xpath(configDataFetcher.configData("tenor_details"))).click();
	return null;
}



public static void clickonclaarotate(WebDriver driver) throws InterruptedException {
	
	Reporter.log("Clicking on the Rotate Button"+"</br>");
	
	Thread.sleep(3000);
	
	for (int i=0;i<4;i++)
	{
		driver.findElement(By.xpath(configDataFetcher.configData("claa_tilt"))).click();
	}
	Reporter.log("Sucess: Clicked on Rotate button 4 times"+"</br>");
}



public static void serachwitinsummary(WebDriver driver) throws InterruptedException {
	// TODO Auto-generated method stub
	
	Thread.sleep(2000);
	driver.findElement(By.xpath("//*[@id=\'root\']/div/div[1]/div/div/div[2]/div/div/div[1]/div[1]/table/thead/tr/th[1]/div/input")).sendKeys("21647356");
	Thread.sleep(3000);
	
	Reporter.log("Searching for a WIT: 21091242");
	
}
	
	
}
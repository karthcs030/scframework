package org.totalqa.pages;


import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.totalqa.util.*;
 
public class IOQueue{
 
	static WebDriver driver;
	static ConfigFileReader configFileReader;
	static configDataFetcher configdata;
	//static Date date1;
	
	public static String datereturn() {
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		//get current date time with Date()
		Date date = new Date();
		// Now format the date
		String date1= dateFormat.format(date);
		return date1=date1.toString();
	}
	 
 
	public IOQueue(WebDriver driver)
	{
		this.driver = driver;
		configFileReader= new ConfigFileReader();
		
 
	}

	
	public static String dateenter(WebDriver driver) {

		//driver.findElement(By.xpath(configDataFetcher.configData("from_date"))).clear();
		Reporter.log("Reading From date");
		
//driver.findElement(By.xpath(configDataFetcher.configData("from_date"))).sendKeys(datereturn());
String s = driver.findElement(By.xpath(configDataFetcher.configData("from_date"))).getAttribute("value");
Reporter.log("From date entered in search value is: "+s +" </br>");
//driver.findElement(By.xpath(configDataFetcher.configData("to_date"))).clear();	
Reporter.log("Changing the TO date ");
//driver.findElement(By.xpath(configDataFetcher.configData("to_date"))).sendKeys(datereturn());
String s1 = driver.findElement(By.xpath(configDataFetcher.configData("to_date"))).getAttribute("value");
Reporter.log("From date entered in search value is: "+s1 + " </br>");
Reporter.log("Clicking on Search button ");
driver.findElement(By.xpath(configDataFetcher.configData("search"))).click();
return s1;

	}
	
	public static String ClickonInputWIT(WebDriver driver) {
		
		dateenter(driver);
		
		String total_wits=driver.findElement(By.xpath(configDataFetcher.configData("wit_number"))).getText();
		int total_no_wit = Integer.parseInt(total_wits);
		if(total_no_wit!=0)
		{
			Reporter.log("Clicked on Export button" + " </br>");
			driver.findElement(By.xpath(configDataFetcher.configData("export_button"))).click();
			Reporter.log("Downloading data in csv format" +  "</br>");
		}
		
		else
		{
		
			Reporter.log("No Records found in this Tab" + " </br>");
		
		}
		return total_wits;
	}


	public static String clickiorefresh(WebDriver driver) throws InterruptedException {
		
		//driver.findElement(By.xpath(configFileReader.getiolink())).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath(configDataFetcher.configData("IO_refresh"))).click();
		Reporter.log("Sucess: Refresh page is working fine in IO page");
		return null;
	}


	public static String infoviewTabTesting(WebDriver driver) throws InterruptedException {
		
		driver.findElement(By.xpath(configDataFetcher.configData("infoviewreport"))).click();
		Reporter.log("Clicked on the Infoview report tab");
		Thread.sleep(2000);
		dateenter(driver);
		
		if (driver.findElement(By.xpath(configDataFetcher.configData("totalwits_infoview"))).isDisplayed())
		{
				String total_wits=driver.findElement(By.xpath(configDataFetcher.configData("totalwits_infoview"))).getText();
		int total_no_wit = Integer.parseInt(total_wits);
		//if(total_no_wit!='0')
		//{
			Reporter.log("Clicked on Export button" +  "</br>");
			driver.findElement(By.xpath(configDataFetcher.configData("export_button"))).click();
		//}
		}
			//return s1;
		else
		{
		
			Reporter.log("No Records found in this Tab" + " </br>");
		
		}
		return null;
		
	}


	public static String reconcillationTesting(WebDriver driver) {
		
		driver.findElement(By.xpath(configDataFetcher.configData("reconcillationreport"))).click();
		Reporter.log("Clicked on the Reconcillation report Tab");
		dateenter(driver);		
		String total_wits=driver.findElement(By.xpath(configDataFetcher.configData("total_wits"))).getText();
		int total_no_wit = Integer.parseInt(total_wits);
		if(total_no_wit!=0)
		{
			Reporter.log("Clicked on Export button");
			driver.findElement(By.xpath(configDataFetcher.configData("export_button"))).click();
		}
		
		else
		{
		
			Reporter.log("No Records found in this Tab" + " </br>");
		
		}//return s1;
		
		return null;
	}


	public static String clickonsummary(WebDriver driver) throws InterruptedException {
		
		Thread.sleep(2000);
		driver.findElement(By.linkText("Summary")).click();
		Thread.sleep(5000);
		String actual = driver.findElement(By.className(configFileReader.gethomepageheading())).getText();
		return actual;
	
	}
	
}
	

package org.totalqa.pages;


import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Reporter;
import org.totalqa.util.*;

public class LoginPage{

	//Inititalization of Static variables
	static WebDriver driver;
	static ConfigFileReader configFileReader;
	static configDataFetcher configdata;

	//Constructor to intialize driver

	public LoginPage(WebDriver driver)
	{
		this.driver = driver;
		configFileReader= new ConfigFileReader();

	}
	public String  login(String username,String password) throws InterruptedException
	{

		//This method is used for logging into application by providing valid username and password

		driver.findElement(By.id(configFileReader.getusername())).sendKeys(username);
		Reporter.log("Username Entered sucesssfully"+"</br>");
		driver.findElement(By.id(configFileReader.getpassword())).sendKeys(password);
		Reporter.log("Password Entered sucesssfully"+"</br>");
		driver.findElement(By.xpath(configFileReader.getloginbutton())).click();
		Reporter.log("Clicked on login button"+"</br>");

		Thread.sleep(5000);

		String actual = driver.findElement(By.xpath(configFileReader.gethomepageheading())).getText();
		return actual;

	}

	public String  invalidlogin(String username,String password) throws InterruptedException
	{

		//This method is used for logging into application by providing invalid username and password
		Reporter.log("Login page loaded sucessfully:"+"</br>");
		driver.findElement(By.id(configFileReader.getusername())).sendKeys(username);
		Reporter.log("Username Entered sucesssfully"+"</br>");
		driver.findElement(By.id(configFileReader.getpassword())).sendKeys(password);
		Reporter.log("Password Entered sucesssfully"+"</br>");
		driver.findElement(By.xpath(configFileReader.getloginbutton())).click();
		Reporter.log("Clicked on login button"+"</br>");


		String actual = driver.findElement(By.xpath(configDataFetcher.configData("invalidlogindetails"))).getText();
		driver.findElement(By.xpath(configDataFetcher.configData("invalidlogin"))).click();
		return actual;

	}

	public static String clickonauditlink() throws InterruptedException {

		//This method is used for clicked on audit link from the home page
		driver.findElement(By.xpath("/html/body/app-root/div[1]/div[2]/ul/li[2]/a")).click();
		Thread.sleep(5000);
		Reporter.log("Clicked on Audit Link"+"</br>");

		String actual = driver.findElement(By.xpath(configFileReader.getauditscreenheading())).getText();
		driver.navigate().back();	
		return actual;

	}

	public static String clickonIOLInk() throws InterruptedException {
		//This method is used for clicked on IO link from the home page

		driver.findElement(By.xpath(configFileReader.getiolink())).click();
		Reporter.log("Clicked on Input/Output Queue Link"+"</br>");
		Thread.sleep(1000);
		String s = driver.findElement(By.xpath(configDataFetcher.configData("from_date"))).getText();
		Reporter.log("Clicked on the date field"+"</br>");	
		String actual = driver.findElement(By.xpath(configFileReader.getioscreenheading())).getText();
		//driver.navigate().back();
		return actual;

	}
	public static String clickonOnMake() throws InterruptedException {

		//This method is used for clicking on Make Button/Buttons
Thread.sleep(3000);
		//driver.findElement(By.xpath(configFileReader.getsummarylink())).click();
		driver.findElement(By.xpath(configDataFetcher.configData("Make_button"))).click();
		Thread.sleep(3000);
		//driver.findElement(By.xpath(configDataFetcher.configData("backto_summary"))).click();
		/*List<WebElement> make_button = driver.findElements(By.xpath(".//button[contains(text(),'Make')]"));
		int n = make_button.size();

		for (int i = 0;i<n; i++)
		{
			make_button.get(i).click();
			driver.findElement(By.xpath("/html/body/app-root/app-sanction-screening-summary/app-segmented-wit-modal/div[1]/div[1]/button")).click();
			driver.findElement(By.xpath("/html/body/app-root/div[1]/div[2]/ul/li[1]/a")).click();
			Thread.sleep(2000);
		}
		 */
		return null;
	}
	public static String clickonOnLogout() throws InterruptedException {

		//This method is used for clicking on logout button and read the text in logout page

		driver.findElement(By.xpath(configFileReader.getlogoutlocator())).click();
		Reporter.log("Clicked on the logout button"+"</br>");
		//Reporter.log("Clicking on the Application form"+"</br>");
		Actions action = new Actions(driver);
		driver.findElement(By.className("PDFComponent__rightTop")).click();
		action.sendKeys(Keys.ARROW_DOWN);
		action.sendKeys(Keys.ARROW_DOWN);
		action.sendKeys(Keys.ENTER);
		action.build().perform();

		Thread.sleep(3000);
		Reporter.log("Sucess!!! Clicked on the Application form"+"</br>");

		//driver.findElement(By.xpath(configFileReader.getlogoutprompt())).click();
		String actual = driver.findElement(By.xpath(configFileReader.getlogoutmessage())).getText();
		return actual;
	}
	public static String clickonOnpagination() {

		//This method is used for summary screen pagination verification

		//driver.findElement(By.xpath(configFileReader.getsummarylink())).click();
		List<WebElement> page_no = driver.findElements(By.className(configFileReader.getpagination()));

		int n = page_no.size();

		Reporter.log("Identified pagination in a page"+"</br>");

		if(n==0)
		{
			Reporter.log("No pagination Identitified in a page"+"</br>");


			for (int i =0;i<n;i++)
			{
				page_no.get(i).click();
				String title = page_no.get(i).getText();
				Reporter.log(title);
			}
		}

		return null;
	}
	public static String enterwittype(String WIT_Type) {

		//This method is used for searching a WIT_Type in the summary screen
		//driver.findElement(By.xpath(configFileReader.getsummarylink())).click();
		Reporter.log("Entering a WIT_Type: Data Read from CSV File"+"</br>");
		driver.findElement(By.xpath(configDataFetcher.configData("wittype"))).sendKeys("Fin Receivables");
		String actual = driver.findElement(By.xpath(configFileReader.getwittypetext())).getText();
		Reporter.log("Checking  for the Filter results "+"</br>");
		return actual;


	}
	public static String clickonOnrefresh(String wIT_TYPE) throws InterruptedException {
		//This method is used for verification of refresh button functionality in summary screen
		//driver.findElement(By.xpath(configFileReader.getsummarylink())).click();
		driver.findElement(By.xpath(configDataFetcher.configData("wittype"))).sendKeys("Fin Receivables");
		//Thread.sleep(2000);
		driver.findElement(By.xpath(configFileReader.getrefreshbutton())).click();
		Reporter.log("Clicked on a Refresh button on Home page"+"</br>");
		//Thread.sleep(10000);
		String actual = driver.findElement(By.xpath(configFileReader.getwittype())).getText();
		Reporter.log("Identified pagination in a page"+"</br>");
		return actual;

	}

	public static boolean clickOnsortWIT() throws InterruptedException {
		//This method is used for clicking on sort button of WIT in summary screen

		Reporter.log("Clicking on Sort function: WIT"+"</br>");
		driver.findElement(By.xpath(configDataFetcher.configData("witsort"))).click();
		String first_text = driver.findElement(By.xpath(configDataFetcher.configData("first_text_results"))).getText();
		String second_text= driver.findElement(By.xpath(configDataFetcher.configData("second_text_results"))).getText();
		long first_text_num=Long.parseLong(first_text);
		long second_text_num=Long.parseLong(second_text);
		if (first_text_num >second_text_num)
		{
			return true;
		}

		else return false;
	}

	public static boolean clickOnsortOperorg() {

		//This method is used for clicking on sort button of OPERORG in summary screen
		Reporter.log("Clicking on Sort function: OPER ORG"+"</br>");
		driver.findElement(By.xpath(configDataFetcher.configData("sort_operorg"))).click();
		String first_text = driver.findElement(By.xpath(configDataFetcher.configData("first_text_results"))).getText();
		String second_text= driver.findElement(By.xpath(configDataFetcher.configData("second_text_results"))).getText();
		long first_text_num=Long.parseLong(first_text);
		long second_text_num=Long.parseLong(second_text);
		if (first_text_num >second_text_num)
		{
			return true;
		}

		else return false;

	}
	public static boolean clickOnsortAmount() {

		//This method is used for clicking on sort button of Amount in summary screen
		Reporter.log("Clicking on Sort function: Amount"+"</br>");
		driver.findElement(By.xpath(configDataFetcher.configData("sort_amount"))).click();
		String first_text = driver.findElement(By.xpath(configDataFetcher.configData("first_text_results"))).getText();
		String second_text= driver.findElement(By.xpath(configDataFetcher.configData("second_text_results"))).getText();
		long first_text_num=Long.parseLong(first_text);
		long second_text_num=Long.parseLong(second_text);
		if (first_text_num >second_text_num)
		{
			return true;
		}

		else return false;

	}
	public static boolean clickonsorthubduedate() {

		//This method is used for clicking on sort button of Hubduedate in summary screen
		Reporter.log("Clicking on Sort function: Hub Due date"+"</br>");
		driver.findElement(By.xpath(configDataFetcher.configData("sort_hubduedate"))).click();
		String first_text = driver.findElement(By.xpath(configDataFetcher.configData("first_text_results"))).getText();
		String second_text= driver.findElement(By.xpath(configDataFetcher.configData("second_text_results"))).getText();
		long first_text_num=Long.parseLong(first_text);
		long second_text_num=Long.parseLong(second_text);
		if (first_text_num >second_text_num)
		{
			return true;
		}

		else return false;

	}
	public static boolean clickonsortlogtime() {

		//This method is used for clicking on sort button of Logtime in summary screen
		Reporter.log("Clicking on Sort function: Hub Due date"+"</br>");
		driver.findElement(By.xpath(configDataFetcher.configData("sort_logtime"))).click();
		String first_text = driver.findElement(By.xpath(configDataFetcher.configData("first_text_results"))).getText();
		String second_text= driver.findElement(By.xpath(configDataFetcher.configData("second_text_results"))).getText();
		long first_text_num=Long.parseLong(first_text);
		long second_text_num=Long.parseLong(second_text);
		if (first_text_num >second_text_num)
		{
			return true;
		}

		else return false;

	}
	public static String quitdriver(WebDriver driver) {
		//This method is used for closing chrome instance
		driver.close();
		return null;
	}
	public static String clickonfundingamount(String funding_Amount) throws InterruptedException {

		driver.findElement(By.xpath(configDataFetcher.configData("Refresh_button"))).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath(configDataFetcher.configData("filter_amount"))).sendKeys("90,434.61");
		Thread.sleep(2000);
		return funding_Amount;
	}
	public static String clickoncustomer(String party) throws InterruptedException {

		driver.findElement(By.xpath(configDataFetcher.configData("Refresh_button"))).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath(configDataFetcher.configData("filter_customer"))).sendKeys("villa Maria");
		Thread.sleep(2000);
		return null;

	}
	public static String clickonWIT(String wIT_ID) throws InterruptedException {

		driver.findElement(By.xpath(configDataFetcher.configData("Refresh_button"))).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath(configDataFetcher.configData("filter_wit"))).sendKeys("21309760");
		Thread.sleep(2000);
		return null;


	}
}
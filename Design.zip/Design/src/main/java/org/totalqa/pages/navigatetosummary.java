package org.totalqa.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class navigatetosummary {

	WebDriver driver;
	 
	public navigatetosummary(WebDriver driver)
	{
		this.driver = driver;
 
	}
	public String register() throws InterruptedException
	{
 
		//Enter username
		driver.findElement(By.xpath("//*[@id=\"orderquery\"]")).sendKeys("0081032529");
		//Enter password
		Thread.sleep(15000);
		driver.findElement(By.cssSelector("#orderFilter")).click();
		Thread.sleep(15000);
		String actual = driver.findElement(By.cssSelector("//*[@id=\"orderhistorycollection\"]/ul/div/div[1]/div/div/div/dl[1]/dt/strong")).getText();
 return actual;
		
	}
}

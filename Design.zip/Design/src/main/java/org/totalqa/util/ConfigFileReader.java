package org.totalqa.util;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;
 
public class ConfigFileReader {
 
 private Properties properties;
 private final String propertyFilePath= "C:\\NotBackedUp\\project_code\\HybridFramework-master\\HybridFramework-master\\Hybridframework\\Hybridframework\\Design\\src\\test\\resources\\binaries\\config.properties";
 
 
 public ConfigFileReader(){
	 //Method to load property file and read the data in key value pair.
 BufferedReader reader;
 try {
 reader = new BufferedReader(new FileReader(propertyFilePath));
 properties = new Properties();
 try {
 properties.load(reader);
 reader.close();
 } catch (IOException e) {
 e.printStackTrace();
 }
 } catch (FileNotFoundException e) {
 e.printStackTrace();
 throw new RuntimeException("Configuration.properties not found at " + propertyFilePath);
  } 
  
 
 }


public String getusername() {
	// TODO Auto-generated method stub
	String username = properties.getProperty("username");
	//System.out.println(username);
	return username;
}

public String getpassword() {
	String password = properties.getProperty("password");
	//System.out.println(password);
	return password;
}

public String getloginbutton() {
	String password = properties.getProperty("login");
	//System.out.println(password);
	return password;
}

public String getsummarylink() {
	String password = properties.getProperty("summary_link");
	//System.out.println(password);
	return password;
}

public String gethomepageheading() {
	String password = properties.getProperty("Homepageheading");
	//System.out.println(password);
	return password;
}

public String getpagination() {
	String password = properties.getProperty("pagination");
	//System.out.println(password);
	return password;
}

public String getwitid() {
	String password = properties.getProperty("witno");
	//System.out.println(password);
	return password;
}

public String getwittype() {
	String password = properties.getProperty("wittype");
	//System.out.println(password);
	return password;
}

public String getiolink() {
	String password = properties.getProperty("IOLink");
	//System.out.println(password);
	return password;
}

public String getwitidtext() {
	String password = properties.getProperty("wittext");
	//System.out.println(password);
	return password;
}

public String getwittypetext() {
	String password = properties.getProperty("wittypetext");
	//System.out.println(password);
	return password;
}

public String getrefreshbutton() {
	String password = properties.getProperty("Refresh_button");
	//System.out.println(password);
	return password;
}



public String getauditscreenheading() {
	String password = properties.getProperty("auditheading");
	//System.out.println(password);
	return password;
}

public String getioscreenheading() {
	String password = properties.getProperty("IOHeading");
	//System.out.println(password);
	return password;
}

public String getinfoviewreport() {
	String password = properties.getProperty("infoviewreport");
	//System.out.println(password);
	return password;
}

public String getreconcilation() {
	String password = properties.getProperty("reconcillationreport");
	//System.out.println(password);
	return password;
}

public String getMakebuttonlocator() {
	String password = properties.getProperty("Make_button");
	//System.out.println(password);
	return password;
}

public String getlogoutlocator() {
	String password = properties.getProperty("logout_button");
	//System.out.println(password);
	return password;
}

public String getlogoutprompt() {
	String password = properties.getProperty("logout_prompt");
	//System.out.println(password);
	return password;
}
	
	public String getlogoutmessage() {
		String password = properties.getProperty("logout_message");
		//System.out.println(password);
		return password;
}


}
package org.totalqa.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.Reader;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

// au.com.bytecode.opencsv.CSVReader;

/**
 * This class mainly meant to get the data from Csv file format
 * 
 * @author lakshmk6
 * @version 1.0
 * @since 1.0
 */
public class DataFetcher {
	private String fileName = null;
	private static final Logger s_logger = LoggerFactory
			.getLogger(DataFetcher.class);

	/**
	 * This is the constructor to assign file name.
	 * 
	 * @param fileName
	 */
	public DataFetcher(String fileName) {
		this.fileName = fileName;
	}

	/**
	 * This function is to read data from CSV
	 * 
	 * @return Data from CSV in array of string format
	 * @throws IOException
	
	public String[][] getDataFromCSV() {
		String dataSet[][] = null;
		if (fileName.endsWith(".csv")) {
			try {
				Reader csvReader = new FileReader(fileName);
				CSVReader cs = new CSVReader(csvReader);
				String[] nextLine = cs.readNext();
				String[] rowLine = null;
				if (nextLine != null) {
					List<String[]> content = cs.readAll();
					int row = content.size();
					int column = nextLine.length;
					dataSet = new String[row][column];
					int j = 0;
					for (String[] object : content) {
						rowLine = object;
						for (int i = 0; i < rowLine.length; i++) {
							dataSet[j][i] = rowLine[i].trim();
						}
						j++;
					}
					content.clear();
				}
				cs.close();
			} catch (Exception e) {

			}
		}
		return dataSet;
	}

	/**
	 * This function is to get data from XLS with sheet Name
	 * 
	 * @return Data from XLS in array of String format
	 * @throws IOException
	 */
	public String[][] getDataFromXLSFromSheet(String sheetName) {
		String dataSet[][] = null;
		if (fileName.endsWith(".xls")||fileName.endsWith(".xlsx")) {
			File inputWorkbook = new File(fileName);
			Workbook workbook;
			try {
				workbook = Workbook.getWorkbook(inputWorkbook);
				Sheet sheet = workbook.getSheet(sheetName);
				int numberOfColumns = sheet.getColumns();
				int numberOfRows = sheet.getRows();
				dataSet = new String[numberOfRows - 1][numberOfColumns];
				for (int i = 1; i < numberOfRows; i++) {
					for (int j = 0; j < numberOfColumns; j++) {
						Cell cell = sheet.getCell(j, i);
						dataSet[i - 1][j] = cell.getContents();
					}
				}
			} catch (Exception e) {
				s_logger.info("Exception in reading XLS file" + e.getMessage());
			}
		}
		return dataSet;
	}

	/**
	 * This function is to get data from XLS with sheet Name
	 * 
	 * @return Data from Xlxs in array of String format
	 * @throws IOException
	 */
	public String[][] getDataFromXlsxtbySheetName(String sheetName) {
		String dataSets[][] = null;
		if (fileName.endsWith(".xlsx")) {
			try {
				File inputWorkbook = new File(fileName);
				FileInputStream fis = new FileInputStream(inputWorkbook);
				XSSFWorkbook workbook;
				workbook = new XSSFWorkbook(fis);
				XSSFSheet sheet = workbook.getSheet(sheetName);
				int totalRow = sheet.getLastRowNum() + 1;
				int totalColumn = sheet.getRow(0).getLastCellNum();
				dataSets = new String[totalRow - 1][totalColumn];
				for (int i = 1; i < totalRow; i++) {
					XSSFRow rows = sheet.getRow(i);
					for (int j = 0; j < totalColumn; j++) {
						XSSFCell cell = rows.getCell(j);
						if (cell == null)
							dataSets[i - 1][j] = "";
						else {
							
							if(j == 0) {
								
								
								//System.out.println("The value of WIT ID" + cell.toString());
								//System.out.println("The Parsed value of WIT" + parse(cell.toString()));
								String s = parse(cell.toString());
								dataSets[i - 1][j] = s;
								
							}
							dataSets[i - 1][j] = parse(cell.toString());
						}
					}
				}

			} catch (Exception e) {
				s_logger.info("Exception in reading Xlxs file" + e.getMessage());
			}
		}
		return dataSets;
	}

	/**
	 * This function is to get data from XLS with sheet Name
	 * 
	 * @return Data from XLS in array of String format
	 * @throws IOException
	 */
	public String[][] getSingleDataFromXLSFromSheet(String sheetName,
			Integer row) {
		String dataSet[][] = null;
		if (fileName.endsWith(".xls")) {
			File inputWorkbook = new File(fileName);
			Workbook workbook;
			try {
				workbook = Workbook.getWorkbook(inputWorkbook);
				Sheet sheet = workbook.getSheet(sheetName);
				int numberOfColumns = sheet.getColumns();
				int numberOfRows = sheet.getRows();
				dataSet = new String[1][numberOfColumns];
				for (int j = 0; j < numberOfColumns; j++) {
					Cell cell = sheet.getCell(j, row);
					dataSet[0][j] = cell.getContents();
				}
			} catch (Exception e) {
				s_logger.info("Exception in reading XLS file" + e.getMessage());
			}
		}
		return dataSet;
	}
	
	private static String parse(String cell) {
		System.out.println("Parse method is called ");
		Double scNot = Double.parseDouble(cell);
		NumberFormat nf = new DecimalFormat("###########");
		return nf.format(scNot);
	
}
	

	/*public static void main(String[] args) {
		System.out.println(parse("2.2132649E7"));
	}*/
	
	}
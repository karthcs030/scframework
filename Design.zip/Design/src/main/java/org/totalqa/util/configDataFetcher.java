package org.totalqa.util;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;
 
public class configDataFetcher {
 
 private static Properties properties;
 //Properties File path
 private final static String propertyFilePath= "C:\\NotBackedUp\\project_code\\HybridFramework-master\\HybridFramework-master\\Hybridframework\\Hybridframework\\Design\\src\\test\\resources\\binaries\\config.properties";
 
 
 public static String configData(String locator){
	 //Method to load property file and read the data in key value pair.
 BufferedReader reader;
 try {
 reader = new BufferedReader(new FileReader(propertyFilePath));
 properties = new Properties();
 try {
 properties.load(reader);
 reader.close();
 } catch (IOException e) {
 e.printStackTrace();
 }
 } catch (FileNotFoundException e) {
 e.printStackTrace();
 throw new RuntimeException("Configuration.properties not found at " + propertyFilePath);
  } 
 String result = properties.getProperty(locator);
 return result;
 
 }
}

package org.totalqa.util;

import java.io.IOException;

import org.apache.commons.mail.DefaultAuthenticator;
import org.apache.commons.mail.Email;
import org.apache.commons.mail.EmailAttachment;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.MultiPartEmail;
import org.apache.commons.mail.SimpleEmail;

public class Sendemail {

	public static void main(String[] args) throws EmailException, IOException {
		sendanemail();
		
	}
	
	
	public static void sendanemail() throws EmailException{
		
		//method to send email - This will be used to send the reprots as a attachment.
		
		EmailAttachment emailAttachment=new EmailAttachment();
        emailAttachment.setPath("C:\\NotBackedUp\\aa.txt");
        emailAttachment.setDisposition(EmailAttachment.ATTACHMENT);
        emailAttachment.setDescription("Picture Attachment");
        emailAttachment.setName("Picture");
       //Initialize a new multi part email instance
        MultiPartEmail email=new MultiPartEmail();
        //Set email host
        email.setHostName("applicationrelay.corptst.anz.com");
        
        //Set email authentication username and password
        email.setAuthenticator(new DefaultAuthenticator("Global\\Gbl scf_mail_enablerDSA","xBg1m!Xj@sS)fF9T"));
        //Set email host SSL to true
        email.setSSL(false);
        try {
            //Set From email address
            email.setFrom("karthik.lakshmanrao@anz.com");
        } catch (EmailException e) {
            e.printStackTrace();
        }
        //Set email Subject line
        email.setSubject("SCF Test Email");
        try {
            //Set Email Message
            email.setMsg("This is a test from Java Email");
        } catch (EmailException e) {
            e.printStackTrace();
        }
        try {
            //Set Email To Address
            email.addTo("karthik.lakshmanrao@anz.com");
        } catch (EmailException e) {
            e.printStackTrace();
        }
        //add the attachment
        try {
            email.attach(emailAttachment);
        } catch (EmailException e) {
            e.printStackTrace();
        }
        try {
            //Send Email
            email.send();
            System.out.println("Sucessful!! Email sent with an attachment");
        } catch (EmailException e) {
            e.printStackTrace();
        }

    }


}


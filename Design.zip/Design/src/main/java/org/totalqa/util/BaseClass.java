package org.totalqa.util;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;

import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.IHookCallBack;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import io.qameta.allure.Attachment;

 
public class BaseClass {
	//declaring driver for webdriver interface
	protected static WebDriver driver;
	//Reading below three parameters from testng.xml file
	@Parameters({"url","browserType", "headless"})
	@BeforeClass
	//Loaidng configuration file details 
	public void loadConfiguration(String url,String browserType, String headless) throws IOException
	{
		//Below if condition will check the parameters in xml for headless value
		if(headless.equals("true"))
		{
			//Intitalizing chrome driver for headless mode
			System.setProperty("webdriver.chrome.driver", "C:\\NotBackedUp\\chromedriver_win32\\chromedriver.exe");
			ChromeOptions options = new ChromeOptions();
		       options.addArguments("--headless", "--disable-gpu", "--window-size=1980,1080","--ignore-certificate-errors", "--silent", "--no-sandbox","--disable-translate","--disable-extensions", "--proxy-server='direct://'", "--proxy-bypass-list=*");
		      // WebDriver driver = new ChromeDriver(options);
		      // DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		       //capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		        //capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		        //driver = {new ChromeDriver(capabilities)};
			driver = new ChromeDriver(options);
			//driver.manage().window().maximize();
			Reporter.log("Automation Tests are running in Headless mode");
			//driver.get("https://mlaas-bgtee-ui-mlaas-bgtee.apps.cpaas.qa.service.test");
		}
		else  if(browserType.equals("CH"))
		{
			//Intitalizing chrome browser for UI mode
			System.setProperty("webdriver.chrome.driver", "C:\\NotBackedUp\\chromedriver_win32\\chromedriver.exe");
			
			driver = new ChromeDriver();
			driver.manage().window().maximize();
			driver.get(url);
		}
		
		else if(browserType.equals("FF"))
		{
			//Intitalizing Firefox browser for UI mode
			System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"/src/test/resources/binaries/geckodriver.exe");
			driver = new FirefoxDriver();
		}
		else
		{
			//Intitalizing IE browser browser for UI mode
			System.setProperty("webdriver.ie.driver",System.getProperty("user.dir")+"/src/test/resources/binaries/IEDriverServer.exe");
			driver = new InternetExplorerDriver();
		}
		//Variable url will fetch the url whihc is mentioned in xml file
		driver.get(url);
		//Implicit wait defined for 50 seconds
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		
 
 
	}
	
	//Date return functionality 
	public static String datereturn() {
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		//get current date time with Date()
		Date date = new Date();
		// Now format the date
		String current_date= dateFormat.format(date);
		current_date=current_date.toString();
		return current_date;
	}
	// Extent report inclusion code
	
	/*@BeforeTest
	 public void startReport(){
	 //ExtentReports(String filePath,Boolean replaceExisting) 
	 //filepath - path of the file, in .htm or .html format - path where your report needs to generate. 
	 //replaceExisting - Setting to overwrite (TRUE) the existing file or append to it
	 //True (default): the file will be replaced with brand new markup, and all existing data will be lost. Use this option to create a brand new report
	 //False: existing data will remain, new tests will be appended to the existing report. If the the supplied path does not exist, a new file will be created.
	 extent = new ExtentReports (System.getProperty("user.dir") +"/test-output/STMExtentReport.html", true);
	 //extent.addSystemInfo("Environment","Environment Name")
	 extent
	                .addSystemInfo("Host Name", "SoftwareTestingMaterial")
	                .addSystemInfo("Environment", "Automation Testing")
	                .addSystemInfo("User Name", "Rajkumar SM");
	                //loading the external xml file (i.e., extent-config.xml) which was placed under the base directory
	                //You could find the xml file below. Create xml file in your project and copy past the code mentioned below
	                extent.loadConfig(new File(System.getProperty("user.dir")+"\\extent-config.xml"));
	 }
	/**
	 * screenShot method is invoked whenever the Testcase is Failed.
	 * @param name
	 * @param driver
	 * @return
	 */
	//Report NG screenshot addition method
	public static void screenCapture() throws IOException
	{
        
		Random random = new Random();
		System.setProperty("org.uncommons.reportng.escape-output", "false");
        File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
        String Path = System.getProperty("user.dir")+"/test-output/screenshots/html";
        File screenshotName = new File(Path +random.hashCode()+".png");
        //Now add screenshot to results by copying the file
        FileUtils.copyFile(scrFile, screenshotName);
        Reporter.log("<br>  <img src='"+screenshotName+"' height='100' width='100' /><br>");
        Reporter.log("<a href="+screenshotName+"></a>");

	}
	
	//Allure report screenshot method
	@Attachment(value = "Screenshot of {0}", type = "image/png")
	public byte[] saveScreenshot(String name, WebDriver driver) {
		return (byte[]) ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
	}
 //Overrriding IhookcallBack interface for enabling listeners for TestNG test
	public void run(IHookCallBack iHookCallBack, ITestResult iTestResult) {
		iHookCallBack.runTestMethod(iTestResult);
		if (iTestResult.getThrowable() != null) {
			this.saveScreenshot(iTestResult.getName(), driver);
		}
	}
		 @AfterMethod //AfterMethod annotation - This method executes after every test execution
		 public void screenShot(ITestResult result){
		 //using ITestResult.FAILURE is equals to result.getStatus then it enter into if condition
		 if(ITestResult.FAILURE==result.getStatus()){
		 try{
		 // To create reference of TakesScreenshot
		 TakesScreenshot screenshot=(TakesScreenshot)driver;
		 // Call method to capture screenshot
		 File src=screenshot.getScreenshotAs(OutputType.FILE);
		 // Copy files to specific location 
		 // result.getName() will return name of test case so that screenshot name will be same as test case name
		 FileUtils.copyFile(src, new File(("user.dir")+"\\target\\screenshots"+result.getName()+".png"));
		 System.out.println("Successfully captured a screenshot");
		 }catch (Exception e){
		 System.out.println("Exception while taking screenshot "+e.getMessage());
		 } 
		 }
		// driver.quit();
		 }
		/*// Get and store window handles in array
		  Set<String> AllWindowHandles = driver.getWindowHandles();
		  String window1 = (String) AllWindowHandles.toArray()[0];
		  System.out.print("window1 handle code = "+AllWindowHandles.toArray()[0]);
		  String window2 = (String) AllWindowHandles.toArray()[1];
		  System.out.print("\nwindow2 handle code = "+AllWindowHandles.toArray()[1]);
		  
		  //Switch to window2(child window) and performing actions on it.
		  driver.switchTo().window(window2);
		*/
		
		
		

	
	
}
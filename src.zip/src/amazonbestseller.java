import java.util.List;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class amazonbestseller {

	@Test
	
	
	public static void addheadsetstocart() throws InterruptedException {
		// Path to chrome driver
		String propertyFilePath = System.getProperty("user.dir") + "\\src\\binaries\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", propertyFilePath);

		// Initialization of chrome driver
		WebDriver driver = new ChromeDriver();
		// Implicit wait declared
		WebDriverWait wait = new WebDriverWait(driver, 20);
		// Actions class Initialization
		Actions action = new Actions(driver);

		// opening amazon.com home page using url
		driver.get("https://www.amazon.com");
		// Maximizing window
		driver.manage().window().maximize();

		System.out.println(driver.getCurrentUrl());

		// entering the text headsets into search box og amazon home page
		driver.findElement(By.id("twotabsearchtextbox")).sendKeys("headsets");
		driver.findElement(By.className("nav-input")).click();

		List<WebElement> bestSellers = driver.findElements(By.xpath(
				"//span[text()='Best Seller']/ancestor::div[@class='sg-row']/following-sibling::div[@class='sg-row']/child::div[1]"));
		for (int i = 1; i <= bestSellers.size(); i++)

		{
			// clicking on headesets with best seller tag one by one
			action.moveToElement(wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(
					"(//span[text()='Best Seller']/ancestor::div[@class='sg-row']/following-sibling::div[@class='sg-row']/child::div[1])["
							+ i + "]"))))
					.build().perform();
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath(
					"(//span[text()='Best Seller']/ancestor::div[@class='sg-row']/following-sibling::div[@class='sg-row']/child::div[1])["
							+ i + "]")))
					.click();
			driver.findElement(By.id("add-to-cart-button")).click();
			if (driver.findElements(By.xpath("//*[@id=\"huc-v2-order-row-center\"]")).size() > 0) {
				driver.navigate().back();

			} else {
				wait.until(ExpectedConditions.elementToBeClickable(By.id("attach-close_sideSheet-link"))).click();
				Thread.sleep(3000);
				driver.navigate().back();
			}

			Thread.sleep(2000);
			driver.navigate().back();
		}
	}
}